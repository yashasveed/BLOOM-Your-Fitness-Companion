package com.miu.meditationapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class yoga : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_yoga)
    }
}